#!/usr/bin/python
import random

FLAG = "flag{REMOVED}"

ARGS = (2**31, 7**6, 5)


class RNG:

    def __init__(self, m, a, b, seed=None):
        self.m = m
        self.a = a
        self.b = b
        if not seed:
            seed = random.randint(0, m - 1)
        self.val = seed


    def get_val(self, lower, upper):
        rng = upper - lower
        return (self.val % rng) + lower


    def step(self, n = 1):
        for i in range(n):
            self.val = (self.a * self.val + self.b) % self.m


WELCOME_TEXT = """Welcome to Guessy!
Guess the number correctly on the first try ten times in a row to receive a special price!"""


def main():
    r = RNG(*ARGS)
    print(WELCOME_TEXT)
    correct_on_first_try = 0
    while correct_on_first_try < 10:
        n = r.get_val(1, 101)
        user_input = - 1
        guesses = 0
        print("New round, go ahead and guess!")
        while True:
            try:
                user_input_text = input()
                user_input = int(user_input_text)
            except Exception as e:
                print("Not a Number!")
                return
            guesses += 1
            if user_input == n and  guesses == 1:
                print("Correct guess on first try!")
                correct_on_first_try += 1
                break
            elif user_input == n:
                print("Correct! It took you {} tries though ...".format(guesses))
                correct_on_first_try = 0
                break
            elif user_input > n:
                print("You guessed too high.")
            elif user_input < n:
                print("You guessed too low.")
        r.step()
    print("Well done! Here is your flag: {}".format(FLAG))


if __name__ == "__main__":
    main()
